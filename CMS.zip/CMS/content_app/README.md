# django_rest_framework

## Run project

`
python manage.py runserver
`

## Make Migrations

`
python manage.py makemigrations <app_name>
`
## Migrate after make migrations

`
python manage.py migrate <app_name>
`

### Steps:
- get_started

`
-mkdir assignment_django,
-python -m venv env,
-cd env,
-cd Scripts,
-activate,
-pip install django,
-pip install djangorestframework,
-django-admin startproject cms,
-django-admin startapp content_app,
`
