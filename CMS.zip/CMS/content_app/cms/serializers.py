from rest_framework import serializers
from .models import MyUser, Content


class MyUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = MyUser
        fields = ['email', 'password', 'full_name', 'phone', 'address', 'city', 'state', 'country', 'pincode']


class ContentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Content
        fields = '__all__'
