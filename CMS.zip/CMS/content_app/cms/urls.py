from django.urls import path
from . import views

urlpatterns = [
    path('create_use/', views.userlist, name='create_user'),
    path('get_all_user/', views.userlist, name='get_all_user'),
    path('get_user/<int:pk>', views.user_detail, name='get_single_user'),
    path('update_user/<int:pk>/', views.user_detail, name='update_user'),
    path('delete_user/<int:pk>/', views.user_detail, name='delete_user'),
    path('create_content/', views.contentlist, name='create_content'),
    path('get_all_content/', views.contentlist, name='get_all_content'),
    path('get_content/<int:pk>/', views.content_detail, name='get_single_content'),
    path('update_content/<int:pk>/', views.content_detail, name='update_content'),
    path('delete_content/<int:pk>/', views.content_detail, name='delete_content'),
    path('upload_file/', views.FileUploadView.as_view(), name='upload_file'),

]

# path('create/', views.add_items, name='add-items'),
# path('all/', views.view_items, name='view_items'),
# path('update/<int:pk>/', views.update_items, name='update-items'),
# path('item/<int:pk>/delete/', views.delete_items, name='delete-items'),
