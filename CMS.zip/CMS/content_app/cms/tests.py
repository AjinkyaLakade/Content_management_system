from django.test import TestCase

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase, APIClient
from .models import MyUser, Content
import requests
from content_app import settings
import json
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import permission_classes


# Create your tests here.
class createUserTests(APITestCase):
    databases = '__all__'
    settings.CONTEXT = 'default'

    def test_save_user(self):
        url = reverse('CreateUser')
        url = "http://127.0.0.1:8000"+ url

        data = {
            "email": "Shree@gmail.com",
            "password": "Shree@22",
            "full_name": "Shree Purandare",
            "phone": 8392856473,
            "address": "Beed",
            "city": "Pune",
            "state": "Maharastra",
            "country": "India",
            "pincode": 414044
        }

        response = requests.request("POST", url=url, data=data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

