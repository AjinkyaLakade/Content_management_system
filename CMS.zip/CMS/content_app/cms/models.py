from django.db import models


class MyUser(models.Model):
    # category = models.CharField(max_length=255)
    # subcatgeory = models.CharField(max_length=255)
    # name = models.CharField(max_length=255)
    # amount = models.PositiveIntegerField()
    #
    # def __str__(self) -> str:
    #     return self.name
    email = models.EmailField()
    password = models.CharField(max_length=100, blank=False, null=False)
    full_name = models.CharField(max_length=100, blank=False, null=False)
    phone = models.IntegerField(blank=False, default=0)
    address = models.CharField(max_length=100, blank=False, null=False)
    city = models.CharField(max_length=100, blank=False, null=False)
    state = models.CharField(max_length=100, blank=False, null=False)
    country = models.CharField(max_length=100, blank=False, null=False)
    pincode = models.IntegerField(blank=False, default=0)

    def __str__(self) -> str:
        return self.full_name

class Content(models.Model):
    title = models.CharField(max_length=100)
    body = models.CharField(max_length=100, blank=False, null=False)
    summary = models.CharField(max_length=100, blank=False, null=False)
    # Document = models.CharField(blank=False, null=False)
    categories = models.CharField(max_length=100,blank=False, null=False)

    def __str__(self) -> str:
        return self.title